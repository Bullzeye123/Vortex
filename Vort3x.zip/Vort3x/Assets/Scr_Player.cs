﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scr_Player : MonoBehaviour {
    public GameObject[] tracks;
    private GameObject CurrentTrack;
    private int tracknumber;
	// Use this for initialization
	void Start () {

        CurrentTrack = transform.parent.gameObject;
        for (int i =0; i<6;i++)
        {
            if (CurrentTrack.name.Equals(tracks[i].name))
            {
                tracknumber = i;
            }
            Debug.Log(tracknumber);
        }
               

	}
    private void Update()
    {

        if (Input.GetKeyDown("left"))
        {
            if (tracknumber > 0)
            {
                transform.SetParent(tracks[tracknumber - 1].transform);
                //CurrentTrack = tracks[tracknumber - 1];
                tracknumber = tracknumber - 1;
                transform.Translate(0, -2, -0.1f);
                Debug.Log(tracknumber);
            }
            else
            {
                transform.SetParent(tracks[5].transform);
                tracknumber = 5;
                transform.Translate (0,10,0.5f) ;
                Debug.Log(tracknumber);
            }
        }
        if (Input.GetKeyDown("right"))
        {
            if (tracknumber <5 )
            {
                transform.SetParent(tracks[tracknumber + 1].transform);
                tracknumber = tracknumber +1;
                transform.Translate(0, 2, 0.1f);
                Debug.Log(tracknumber);
            }
        }
    }
    
	void FixedUpdate () {
        /*
        Vector3 move = new Vector3(0.4f,0,0.3f);
        if(transform.position.x == 0)
        {
            speed = 1.0f;
        }
        if (transform.position.x == 10)
        {
            speed = 1.1f;
        }
        if (transform.position.x == 20)
        {
            speed = 1.2f;
        }
        if (transform.position.x == 30)
        {
            speed = 1.3f;
        }
        if (transform.position.x == 40)
        {
            speed = 1.4f;
        }
        if (transform.position.x == 50)
        {
            speed = 1.5f;
        }
        GetComponent<Rigidbody>().AddForce(move*speed);*/
        //player.transform.position.z = player.transform.position.z + 1.0;
		
	}
}
