﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scr_Spin : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(transform.name.Equals("Track6Spin"))
            transform.Rotate(0, 0, -Time.deltaTime*10);
        if (transform.name.Equals("Track5Spin"))
            transform.Rotate(0, 0, -Time.deltaTime * 20);
        if (transform.name.Equals("Track4Spin"))
            transform.Rotate(0, 0, -Time.deltaTime * 30);
        if (transform.name.Equals("Track3Spin"))
            transform.Rotate(0, 0, -Time.deltaTime * 40);
        if (transform.name.Equals("Track2Spin"))
            transform.Rotate(0, 0, -Time.deltaTime * 50);
        if (transform.name.Equals("Track1Spin"))
            transform.Rotate(0, 0, -Time.deltaTime * 60);

    }
}
